
"""
TODO: add a docstring.

"""

# We keep all initialization code in a separate module.

from pystache.init import parse, render, Renderer, TemplateSpec

__all__ = ['parse', 'render', 'Renderer', 'TemplateSpec']

__version__ = '0.5.4'  # Also change in setup.py.
